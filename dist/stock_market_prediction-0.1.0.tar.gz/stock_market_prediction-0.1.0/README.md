# Stock market prediction

## Install

```bash
pip install poetry
poetry install
```	

## Usage

```bash
poetry shell
python -m stock_market_prediction
```